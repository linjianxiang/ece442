Lab2


Lab2.m: main program
down_up_sample.m: function code for Question 4
myhalftone.m: function code for Question 5
colourhalftone.m: function code for Question 6

Blue_Flower.bmp: adjusted image for Question 3
pepper_sampling_2.png,pepper_sampling_4.png,pepper_sampling_8.png: adjusted image for Question 4
lenna_halftone.bmp: adjusted image for Question 5
lenna_colourhalftone.png: ajusted image for Question 6